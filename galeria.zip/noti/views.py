from django.shortcuts import render
from .models import Notification
# Create your views here.
def index_noti(request):
	n = Notification.objects.filter(user=request.user)
	return render(request, 'noti/index.html', {'noti':n})